# ArrayTodolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
