# Todolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**priority** | **Integer** |  |  [optional]
**tags** | **List&lt;String&gt;** |  |  [optional]
