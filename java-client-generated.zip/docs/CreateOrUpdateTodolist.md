# CreateOrUpdateTodolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**priority** | **Integer** |  |  [optional]
**tags** | **List&lt;String&gt;** |  |  [optional]
